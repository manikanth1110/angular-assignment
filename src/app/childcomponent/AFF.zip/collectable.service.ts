import{ Collectable } from "./collectable.model";
import 'reflect-metadata';
import {Component } from '@angular/core';
import { CollectableService } from "app/shared/collectable.service";
import { CollectionComponent } from "app/collection/collection.component";
import { CollectableModel } from "app/shared/collectable.model";
import { MarketComponent } from "app/market/market.component";


export class CollectableService{
    private collectables: Collectable[] = [
        {description:'Avery rare copy of jQuery for Dummies', type:'Book'},
        {description:'The first Letter ever written', type:'Piece of Paper'},
        {description:'A photograph showing nothing', type:'Photo'},
        {description:'A box with all sold Zunes', type:'Garbage'},

    ]};

private Collection: Collectable[] = [];

getCollectables(){
    return this.collectables;
}
getCollection(){
    return this.collection;
}    
 addToCollection(item: Collectable){
     if(this.collection.indexOf(item) !== -1){
         return;
     }
     this.collection.push(item);
 } 
 removeFromCollection(item: Collectable){
     this.collection.splice(this.collection.indexOf(item), 1);

 }   
