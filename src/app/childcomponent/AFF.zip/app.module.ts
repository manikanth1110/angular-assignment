import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { appComponent } from "app/app.component";

import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CollectableService } from "app/shared/collectable.service";
import { CollectionComponent } from "app/collection/collection.component";
import { CollectableModel } from "app/shared/collectable.model";
import { MarketComponent } from "app/market/market.component";

@NgModule({
  declarations: [
    
    
    appComponent,
    CollectionComponent,
    MarketComponent,
    CollectableService,
    CollectableModel,


    

    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule
  ],
  providers: [CollectableService],
  bootstrap: [appComponent]
})
export class AppModule { }
