import { Component, OnInit } from '@angular/core';
import { CollectableService } from "app/shared/collectable.service";
import { Collectable } from "app/shared/collectable.model";
import { Collectioncomponent } from "app/collection/collection.component";

@Component({
    selector: 'app-collection',
    templateUrl: './collection.component.html',
    styles: []
})
export class CollectionComponent implements OnInit{
    collectedItems: Collectable[] = []; 

    constructor(private collectableService: CollectableService) { }

        ngOnInit(){
            this.collectedItems = this.collectableService.getCollection();

        }
   

}
