export class Collectable{
    public description: string;
    public  type: string;

constructor(description: string, type: string) {
    this.description = description;
    this.type= type;
}
}